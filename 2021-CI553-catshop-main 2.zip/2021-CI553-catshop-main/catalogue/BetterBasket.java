package catalogue;

import java.io.Serializable;
import java.util.Collections;
import java.util.Comparator;


public class BetterBasket extends Basket implements Serializable
{
  private static final long serialVersionUID = 1L;


  
  public boolean add( Product pr )
  {
      if(super.add(pr))
      {
          sort();   
          for(int i = 0 ; i < this.size() ; i++ )  
          {
              if(this.get(i).getQuantity() == 0)
              {
                 this.remove(i);        
              }
         }
          return true;
      }
    return false;

  }

  public void sort()
  {
      Collections.sort(this , new Comparator<Product>() {
          @Override
          //defined a public status integer to compare to 2 products
          
          public int compare(Product num1, Product num2) {
        	  //Public’ was set for this method with integer introduced in Java as ‘int’ to compare ‘Product’ and 2 Classes between ‘num1’ and ‘num2’
        	  
              double pr1= num1.getPrice();
              
              double pr2 = num2.getPrice();
              //going to the get or return the price of ‘num1’ ‘num2’ which is set as ‘pr1’ and ‘pr2’
              int pq2 = num2.getQuantity();
              //returns the quantity of ‘pq2’
              if(pr1 == pr2)
              {
            	  //if statement checks if ‘pr1’ and ‘pr2’ are equal it will start running the following two lines inside the if statement.
                  num2.setQuantity(pq2 + 1);
                  num1.setQuantity(0);
                  return 0;
              }
              return pr1<pr2 ? 1 : -1;
          }
      });
  }
}